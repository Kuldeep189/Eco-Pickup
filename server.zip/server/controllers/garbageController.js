const GarbageReport = require("../models/GarbageReport");
const User = require("../models/user");
console.log("🚀 Garbage Report route triggered!");


// 🟢 Report Garbage (with image upload + location)
exports.reportGarbage = async (req, res) => {
  try {
    console.log("✅ Incoming Report Request");
    console.log("Body:", req.body);
    console.log("File:", req.file);

    const { location, address, description, lat, lng } = req.body;

    // Allow either JWT (via middleware) or direct userId
    const userId = req.user ? req.user.id : req.body.userId;

    // Basic validation
    if (!userId || !location || !lat || !lng) {
      console.warn("❌ Missing required fields:", { userId, location, lat, lng });
      return res.status(400).json({ error: "Missing required fields" });
    }

    // Handle uploaded image path
    const imagePath = req.file
      ? `/uploads/${req.file.filename}`
      : req.body.photoUrl || null;

    // ✅ Create the garbage report in MongoDB
    const report = await GarbageReport.create({
      userId,
      photoUrl: imagePath,
      location,
      address: address || "Not provided",
      description: description || "",
      lat,
      lng,
      status: "Pending",
      createdAt: new Date(),
    });

    console.log("✅ Report saved successfully:", report);

    // Add reward points
    await User.findByIdAndUpdate(userId, { $inc: { points: 10 } });

    res.status(201).json({
      message: "✅ Garbage reported successfully",
      report,
    });
  } catch (err) {
    console.error("❌ Error creating report:", err);
    res.status(500).json({ error: "Server error" });
  }
};

// 🟣 Get All Reports of a Specific User
exports.getUserReports = async (req, res) => {
  try {
    const userId = req.user ? req.user.id : req.query.userId;
    if (!userId) return res.status(400).json({ error: "User ID missing" });

    const reports = await GarbageReport.find({ userId }).sort({ createdAt: -1 });
    console.log(`📋 Found ${reports.length} reports for user ${userId}`);
    res.json(reports);
  } catch (err) {
    console.error("❌ Error fetching reports:", err);
    res.status(500).json({ error: "Server error" });
  }
};
