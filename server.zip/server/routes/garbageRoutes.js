const express = require("express");
const router = express.Router();
const multer = require("multer");
const path = require("path");
const { reportGarbage, getUserReports } = require("../controllers/garbageController");
const authMiddleware = require("../middleware/authmidlleware");

// 🔧 Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../uploads"));
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

// 🟢 Routes
router.post("/report", authMiddleware, upload.single("image"), reportGarbage);
router.get("/my-reports", authMiddleware, getUserReports);

module.exports = router;
